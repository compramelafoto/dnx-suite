These fonts are licensed under the SIL Open Font License (OFL).
Source: Google Fonts (https://fonts.google.com).
You may use them freely for personal and commercial projects under OFL terms.
See: https://scripts.sil.org/OFL
